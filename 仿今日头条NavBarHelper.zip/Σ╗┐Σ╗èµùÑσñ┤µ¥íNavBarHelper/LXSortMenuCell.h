//
//  LXSortMenuCell.h
//  LXHorizontalMenu
//
//  Created by NiceForMe on 17/3/25.
//  Copyright © 2017年 BHEC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LXSortMenuCell : UICollectionViewCell
@property (nonatomic,strong) UILabel *itemLable;
@end

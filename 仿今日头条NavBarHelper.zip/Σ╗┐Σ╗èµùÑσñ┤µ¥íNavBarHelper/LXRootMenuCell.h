//
//  LXRootMenuCell.h
//  LXHorizontalMenu
//
//  Created by NiceForMe on 17/2/20.
//  Copyright © 2017年 BHEC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LXRootMenuCell : UICollectionViewCell
@property (nonatomic,strong) UIView *rootMenuView;
@end
